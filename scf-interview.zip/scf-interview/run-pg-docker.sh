#!/usr/bin/env bash
docker run --rm --name pg-docker -v "$(pwd)/init-db.sh:/docker-entrypoint-initdb.d/init-db.sh" -v "$(pwd)/sql:/data/sql" -e POSTGRES_PASSWORD=postgres -p 5432:5432 -d postgres