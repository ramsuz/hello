INSERT INTO scf_sc.facility
    (id, code, level, rts_code, amount)
VALUES
    (1, 'F00001', 'F2','RTS000101', 1000.00),
    (2, 'F00002', 'F1','RTS000101', 1500.00),
    (3, 'F00003', 'F2','RTS000102', 2000.00),
    (4, 'F00004', 'F2','RTS000103', 2000.00),
    (5, 'F00005', 'F2','RTS000104', 3000.00);
    (6, 'F00006', 'F2','RTS000105', 1500.00);

INSERT INTO scf_sc.buyer
    (id, rts_code, name)
VALUES
    (1, 'RTS000101', 'Faurecia'),
    (2, 'RTS000102', 'ICA'),
    (3, 'RTS000103', 'SFR'),
    (3, 'RTS000104', 'AUCHAN');

INSERT INTO scf_sc.prepayment_req
    (id, status, amount, buyer_id)
VALUES
    (1, 'PAID', 520.00, 1),
    (2, 'TO_BE_PAID', 400.00, 1),
    (3, 'RISK_TO_BE_CHECKED', 300.00, 1),
    (4, 'PAID', 520.00, 2),
    (5, 'PAID', 400.00, 3),
    (6, 'RISK_TO_BE_CHECKED', 300.00, 3),
    (7, 'PAID', 520.00, 3),
    (8, 'PAID', 250.50, 3),
    (9, 'REJECTED', 1800.00, 2);