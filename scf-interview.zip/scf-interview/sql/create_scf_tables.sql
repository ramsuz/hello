CREATE TABLE scf_sc.buyer(id int PRIMARY KEY, rts_code varchar(15), name varchar(55));

CREATE TABLE scf_sc.prepayment_req(id int PRIMARY KEY, status varchar(20), amount NUMERIC(18,3), buyer_id int,
	CONSTRAINT fk_buyer
          FOREIGN KEY(buyer_id)
    	  REFERENCES scf_sc.buyer(id));

CREATE TABLE scf_sc.facility(id int PRIMARY KEY, code varchar(15), level char(2), rts_code varchar(15), amount NUMERIC(18,3));