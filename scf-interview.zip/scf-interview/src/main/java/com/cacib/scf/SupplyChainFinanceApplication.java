package com.cacib.scf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupplyChainFinanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupplyChainFinanceApplication.class, args);
	}
}
