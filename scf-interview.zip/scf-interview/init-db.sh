#!/usr/bin/env bash
echo "########### START - INIT DATABASE ###########"

psql --username postgres --dbname postgres -f /data/sql/init-schema.sql
psql --dbname scfdb --username scf_us -f /data/sql/create_scf_tables.sql
psql --dbname scfdb --username scf_us -f /data/sql/insert_data.sql

echo "########### SUCCESS - INIT DATABASE ###########"
