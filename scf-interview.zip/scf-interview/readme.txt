select * from scf_sc.buyer;

select distinct f.rts_code, f.amount from scf_sc.facility f
left join scf_sc.buyer b on f.rts_code = b.rts_code
where f.level = 'F2';


select rts_code, sum(pr.amount) from scf_sc.buyer b
inner join scf_sc.prepayment_req pr on pr.buyer_id = b.id
where pr.status in ('PAID', 'TO_BE_PAID', 'RISK_TO_BE_CHECKED')
group by b.rts_code;

-- pour chaque buyer --> la facilité restante
--case when ba.amount is null then 0 else ba.amount end

select distinct f.rts_code, f.amount - coalesce(ba.amount, 0) from scf_sc.facility f
left join
	(select b.rts_code, sum(pr.amount) amount from scf_sc.buyer b
		inner join scf_sc.prepayment_req pr on pr.buyer_id = b.id
		where pr.status in ('PAID', 'TO_BE_PAID', 'RISK_TO_BE_CHECKED')
		group by b.rts_code) ba on ba.rts_code = f.rts_code ;


-- buyer ayant plus que 2 pre
select b.rts_code, count(pr.id)  from scf_sc.buyer b
inner join scf_sc.prepayment_req pr on b.id = pr.buyer_id
group by b.rts_code
having count(pr.id) > 2
